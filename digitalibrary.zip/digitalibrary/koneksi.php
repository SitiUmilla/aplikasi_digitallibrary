<?php 
$koneksi = mysqli_connect("localhost","latus","password","digitalibrary");

// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}
 
?>